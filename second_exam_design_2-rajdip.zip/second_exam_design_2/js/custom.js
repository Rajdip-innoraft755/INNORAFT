$('.box-1').hover(function(){
    $('.heading1').css({'color':'#febb0c',});
},function() {
    $('.heading1').css({'color':'#0b8087',});
});

$('.box-2').hover(function(){
    $('.heading2').css({'color':'#febb0c',});
},function() {
    $('.heading2').css({'color':'#0b8087',});
});

$('.box-3').hover(function(){
    $('.heading3').css({'color':'#febb0c',});
},function() {
    $('.heading3').css({'color':'#0b8087',});
});


$('.box-4').hover(function(){
    $('.heading4').css({'color':'#febb0c',});
},function() {
    $('.heading4').css({'color':'#0b8087',});
});